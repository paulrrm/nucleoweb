import { Component } from '@angular/core';

@Component({
  selector: 'app-infocontacto',
  standalone: true,
  imports: [],
  templateUrl: './infocontacto.component.html',
  styleUrl: './infocontacto.component.css'
})
export class InfocontactoComponent {

}
