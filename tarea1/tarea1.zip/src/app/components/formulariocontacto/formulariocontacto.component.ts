import { Component } from '@angular/core';

@Component({
  selector: 'app-formulariocontacto',
  standalone: true,
  imports: [],
  templateUrl: './formulariocontacto.component.html',
  styleUrl: './formulariocontacto.component.css'
})
export class FormulariocontactoComponent {

}
