import { Component } from '@angular/core';

@Component({
  selector: 'app-mapcontacto',
  standalone: true,
  imports: [],
  templateUrl: './mapcontacto.component.html',
  styleUrl: './mapcontacto.component.css'
})
export class MapcontactoComponent {

}
